package com.visa.datamodel;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "RULES")
public class RulesTable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SEQUENCE_ID")
	private int sequenceId;

	@Column(name = "RULE_ID", unique = true)
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private String ruleId;

	@Column(name = "CARD_NUMBER", nullable = false)
	private long cardNumber;

	@Column(name = "IDENTIFIER_TYPE", nullable = false)
	private String identifierType;

	@Column(name = "IDENTIFIER_VALUE", nullable = false)
	private String identifierValues;

	@Column(name = "PAYMENTTHERSHOLD", nullable = false)
	private double paymentThreshold;

	@Column(name = "COUNTRY_CODES", nullable = false)
	private String countryCodes;

	@Column(name = "PARTNER_ID", nullable = false)
	private String partnerId;

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	public long getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getIdentifierType() {
		return identifierType;
	}

	public void setIdentifierType(String identifierType) {
		this.identifierType = identifierType;
	}

	public String getIdentifierValues() {
		return identifierValues;
	}

	public void setIdentifierValues(String identifierValues) {
		this.identifierValues = identifierValues;
	}

	public double getPaymentThreshold() {
		return paymentThreshold;
	}

	public void setPaymentThreshold(double paymentThreshold) {
		this.paymentThreshold = paymentThreshold;
	}

	public String getCountryCodes() {
		return countryCodes;
	}

	public void setCountryCodes(String countryCodes) {
		this.countryCodes = countryCodes;
	}

}
