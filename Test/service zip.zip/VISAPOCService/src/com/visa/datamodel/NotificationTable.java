package com.visa.datamodel;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="NOTIFICATION")
public class NotificationTable {

	
	@Id
	@Column(name = "NOTIFICATION_ID", nullable = false)
	private String notificationId;
	
	@Column(name="NOTIFICATION_TYPE", nullable = false)
	private String notificationType;
	
	@Column(name="NOTIFICATION_CONTENT")
	private String content;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="TRANSACTION_DATE_TIME", nullable = false)
	private Date transactionDateTime;
	
	@Column(name="TRANSACTIONAMOUNT", nullable=false)
	private String transactionAmount;
	
	@Column(name="COUNTRY_CODE", nullable=false)
	private String countryCode;	
	
	@Column(name="LINK", nullable=false)
	private String link;
	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="START_FROM_ID", nullable=false)
	private int startFromId;
	
	@Column(name="PARTNER_ID", nullable=false)
	private String partnerId;
	
	public String getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}
	public int getStartFromId() {
		return startFromId;
	}
	public void setStartFromId(int startFromId) {
		this.startFromId = startFromId;
	}
	public String getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}
	public String getNotificationType() {
		return notificationType;
	}
	public void setNotificationType(String notificationType) {
		this.notificationType = notificationType;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getTransactionDateTime() {
		return transactionDateTime;
	}
	public void setTransactionDateTime(Date transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}
	public String getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	
	
}
