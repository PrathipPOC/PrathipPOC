package com.visa.poc;

public class ThreeDSecure {

	private String threeDSecureID;
	private String mOTOECI;
	private String payerAuthenticationResponse;
	private String accountholderAuthenticationValue;
	private String attemptedAuthentication;
	private String verifyEnrollmentStatus;
	private String payerAuthenticationStatus;
	public String getThreeDSecureID() {
		return threeDSecureID;
	}
	public void setThreeDSecureID(String threeDSecureID) {
		this.threeDSecureID = threeDSecureID;
	}
	public String getmOTOECI() {
		return mOTOECI;
	}
	public void setmOTOECI(String mOTOECI) {
		this.mOTOECI = mOTOECI;
	}
	public String getPayerAuthenticationResponse() {
		return payerAuthenticationResponse;
	}
	public void setPayerAuthenticationResponse(String payerAuthenticationResponse) {
		this.payerAuthenticationResponse = payerAuthenticationResponse;
	}
	public String getAccountholderAuthenticationValue() {
		return accountholderAuthenticationValue;
	}
	public void setAccountholderAuthenticationValue(
			String accountholderAuthenticationValue) {
		this.accountholderAuthenticationValue = accountholderAuthenticationValue;
	}
	public String getAttemptedAuthentication() {
		return attemptedAuthentication;
	}
	public void setAttemptedAuthentication(String attemptedAuthentication) {
		this.attemptedAuthentication = attemptedAuthentication;
	}
	public String getVerifyEnrollmentStatus() {
		return verifyEnrollmentStatus;
	}
	public void setVerifyEnrollmentStatus(String verifyEnrollmentStatus) {
		this.verifyEnrollmentStatus = verifyEnrollmentStatus;
	}
	public String getPayerAuthenticationStatus() {
		return payerAuthenticationStatus;
	}
	public void setPayerAuthenticationStatus(String payerAuthenticationStatus) {
		this.payerAuthenticationStatus = payerAuthenticationStatus;
	}
	
	
}
