package com.visa.poc;

public class Response {
	public static final String SUCCESS = "0";
	public static final String FAILED = "1";  
	
	private String message;
	private String code;
	private String id;
	private String link;
	
	public Response(String message, String code, String id, String link) {
		super();
		this.message = message;
		this.code = code;
		this.id = id;
		this.link = link;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	
}
