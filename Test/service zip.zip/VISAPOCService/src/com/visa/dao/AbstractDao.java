package com.visa.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
 
public abstract class AbstractDao {
 
    @Autowired
    private SessionFactory sessionFactory ;
 
    protected Session getSession() {
        return sessionFactory.getCurrentSession();
    }
 
    public int persist(Object entity) {
        //getSession().persist(entity);
        getSession().save(entity);
        return 1;
    }
 
    public int delete(Object entity) {
        getSession().delete(entity);
        return 1;
    }
}