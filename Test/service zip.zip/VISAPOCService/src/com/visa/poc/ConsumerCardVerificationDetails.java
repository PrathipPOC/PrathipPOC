package com.visa.poc;

public class ConsumerCardVerificationDetails {

	private String cardSecurityCodeValue;

	public String getCardSecurityCodeValue() {
		return cardSecurityCodeValue;
	}

	public void setCardSecurityCodeValue(String cardSecurityCodeValue) {
		this.cardSecurityCodeValue = cardSecurityCodeValue;
	}
	
}
