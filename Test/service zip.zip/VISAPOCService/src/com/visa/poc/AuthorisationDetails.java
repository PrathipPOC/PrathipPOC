package com.visa.poc;

public class AuthorisationDetails {

	private String authorisationCode;
	private String acquirerBankIDCode;
	private String acquirerMerchantId;
	private String authorisationTimestamp;

	public String getAuthorisationCode() {
		return authorisationCode;
	}

	public void setAuthorisationCode(String authorisationCode) {
		this.authorisationCode = authorisationCode;
	}

	public String getAcquirerBankIDCode() {
		return acquirerBankIDCode;
	}

	public void setAcquirerBankIDCode(String acquirerBankIDCode) {
		this.acquirerBankIDCode = acquirerBankIDCode;
	}

	public String getAcquirerMerchantId() {
		return acquirerMerchantId;
	}

	public void setAcquirerMerchantId(String acquirerMerchantId) {
		this.acquirerMerchantId = acquirerMerchantId;
	}

	public String getAuthorisationTimestamp() {
		return authorisationTimestamp;
	}

	public void setAuthorisationTimestamp(String authorisationTimestamp) {
		this.authorisationTimestamp = authorisationTimestamp;
	}

}
