package com.visa.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.visa.datamodel.NotificationTable;

@Repository("notificationDao")
@Transactional
public class NotificationDaoImpl extends AbstractDao implements NotificationDao {

	@Override
	public void saveNotification(NotificationTable notification) {
		getSession().save(notification);

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<NotificationTable> findByStartId(Date startId, String partnerId) {
		Criteria criteria = getSession()
				.createCriteria(NotificationTable.class);
		criteria.add(Restrictions.eq("partnerId", partnerId));
		criteria.add(Restrictions.gt("transactionDateTime", startId));
		
		return (List<NotificationTable>) criteria.list();
	}

	@Override
	public NotificationTable findByNotifityId(String notifityId,
			String partnerId) {
		Criteria criteria = getSession()
				.createCriteria(NotificationTable.class);
		criteria.add(Restrictions.eq("partnerId", partnerId));
		criteria.add(Restrictions.eq("notificationId", notifityId));

		return (NotificationTable) criteria.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<NotificationTable> findByPartnerId(String partnerId) {
		Criteria criteria = getSession()
				.createCriteria(NotificationTable.class);
		criteria.add(Restrictions.eq("partnerId", partnerId));
		return (List<NotificationTable>) criteria.list();
	}

}
