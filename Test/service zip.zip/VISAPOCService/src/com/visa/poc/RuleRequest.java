package com.visa.poc;

public class RuleRequest {

	private String cardNumber;
	private IdentifierType identifierType;
	private String identifierValues;
	private String paymentThreshold;
	private String[] countryCodes;
	
	public String[] getCountryCodes() {
		return countryCodes;
	}
	public void setCountryCodes(String[] countryCodes) {
		this.countryCodes = countryCodes;
	}
	public String getPaymentThreshold() {
		return paymentThreshold;
	}
	public void setPaymentThreshold(String paymentThreshold) {
		this.paymentThreshold = paymentThreshold;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public IdentifierType getIdentifierType() {
		return identifierType;
	}
	public void setIdentifierType(IdentifierType identifierType) {
		this.identifierType = identifierType;
	}
	public String getIdentifierValues() {
		return identifierValues;
	}
	public void setIdentifierValues(String identifierValues) {
		this.identifierValues = identifierValues;
	}
	
	
}
