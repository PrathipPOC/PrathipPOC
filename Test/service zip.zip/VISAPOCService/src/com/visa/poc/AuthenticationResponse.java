package com.visa.poc;

public class AuthenticationResponse {

	private String requestID;
	private String requestType;
	private String vmeMerchantID;
	private ReturnAndResponseDetails returnAndResponseDetails;
	private AuthorisationDetails authorisationDetails;
	private String link;

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getVmeMerchantID() {
		return vmeMerchantID;
	}

	public void setVmeMerchantID(String vmeMerchantID) {
		this.vmeMerchantID = vmeMerchantID;
	}

	public ReturnAndResponseDetails getReturnAndResponseDetails() {
		return returnAndResponseDetails;
	}

	public void setReturnAndResponseDetails(
			ReturnAndResponseDetails returnAndResponseDetails) {
		this.returnAndResponseDetails = returnAndResponseDetails;
	}

	public AuthorisationDetails getAuthorisationDetails() {
		return authorisationDetails;
	}

	public void setAuthorisationDetails(
			AuthorisationDetails authorisationDetails) {
		this.authorisationDetails = authorisationDetails;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

}
