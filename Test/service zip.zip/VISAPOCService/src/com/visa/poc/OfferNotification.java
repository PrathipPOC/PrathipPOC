package com.visa.poc;

public class OfferNotification {

	private  Notification[] notifications;

	public Notification[] getNotifications() {
		return notifications;
	}

	public void setNotifications(Notification[] notifications) {
		this.notifications = notifications;
	}

	
}
