package com.visa.dao;

import java.util.List;
import com.visa.datamodel.RulesTable;

public interface RulesDao {

	int saveRules(RulesTable rule);

	List<RulesTable> findAllRule();

	int deleteRulesById(String ruleId, String partnerId);

	int deleteRuleByPartnerId(String partnerId);

	boolean findRuleCountryCode(long cardNo, String countryCode,
			String identifierValue, String partnerId);

	List<RulesTable> findById(String ruleId, String partnerId);

	List<RulesTable> findByIdvalueIdentifier(String ruleId,String partnerId,
			String identifiervalue, String identifierType);

	List<RulesTable> findByPartnerId(String partnerId);

	void updateRules(RulesTable rule);

	RulesTable findRuleByCardNo(long CardNo, String countryCode,
			String identifierId);

}
