package com.visa.poc;

public class VmeTransactionIdentifier {

	private String vmeUniqueId;
	private String authenticationMethod;
	private String authenticationReasonCode;
	public String getVmeUniqueId() {
		return vmeUniqueId;
	}
	public void setVmeUniqueId(String vmeUniqueId) {
		this.vmeUniqueId = vmeUniqueId;
	}
	public String getAuthenticationMethod() {
		return authenticationMethod;
	}
	public void setAuthenticationMethod(String authenticationMethod) {
		this.authenticationMethod = authenticationMethod;
	}
	public String getAuthenticationReasonCode() {
		return authenticationReasonCode;
	}
	public void setAuthenticationReasonCode(String authenticationReasonCode) {
		this.authenticationReasonCode = authenticationReasonCode;
	}
	
	
}
