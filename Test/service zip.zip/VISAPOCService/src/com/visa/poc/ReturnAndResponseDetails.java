package com.visa.poc;

public class ReturnAndResponseDetails {

	private String authorisationRequestStatus;
	private String returnReasonCode;
	private String pspReturnReasonDescription;
	private String pspPassThroughData;
	private String pspStartTime;
	private String pspEndTime;
	private String nativeCSCResponseCode;
	private String nativeAVSResponseCode;

	public String getAuthorisationRequestStatus() {
		return authorisationRequestStatus;
	}

	public void setAuthorisationRequestStatus(String authorisationRequestStatus) {
		this.authorisationRequestStatus = authorisationRequestStatus;
	}

	public String getReturnReasonCode() {
		return returnReasonCode;
	}

	public void setReturnReasonCode(String returnReasonCode) {
		this.returnReasonCode = returnReasonCode;
	}

	public String getPspReturnReasonDescription() {
		return pspReturnReasonDescription;
	}

	public void setPspReturnReasonDescription(String pspReturnReasonDescription) {
		this.pspReturnReasonDescription = pspReturnReasonDescription;
	}

	public String getPspPassThroughData() {
		return pspPassThroughData;
	}

	public void setPspPassThroughData(String pspPassThroughData) {
		this.pspPassThroughData = pspPassThroughData;
	}

	public String getPspStartTime() {
		return pspStartTime;
	}

	public void setPspStartTime(String pspStartTime) {
		this.pspStartTime = pspStartTime;
	}

	public String getPspEndTime() {
		return pspEndTime;
	}

	public void setPspEndTime(String pspEndTime) {
		this.pspEndTime = pspEndTime;
	}

	public String getNativeCSCResponseCode() {
		return nativeCSCResponseCode;
	}

	public void setNativeCSCResponseCode(String nativeCSCResponseCode) {
		this.nativeCSCResponseCode = nativeCSCResponseCode;
	}

	public String getNativeAVSResponseCode() {
		return nativeAVSResponseCode;
	}

	public void setNativeAVSResponseCode(String nativeAVSResponseCode) {
		this.nativeAVSResponseCode = nativeAVSResponseCode;
	}

}
