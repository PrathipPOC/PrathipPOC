package com.visa.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

import com.visa.datamodel.RulesTable;

@Repository("rulesDao")
@Transactional
public class RuleDaoImpl extends AbstractDao implements RulesDao {

	@Override
	public int saveRules(RulesTable rule) {
		persist(rule);
		return 1;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RulesTable> findAllRule() {
		Criteria criteria = getSession().createCriteria(RulesTable.class);
		return (List<RulesTable>) criteria.list();
	}

	@Override
	public int deleteRulesById(String ruleId, String partnerId) {
		Query query = getSession()
				.createSQLQuery(
						"delete from RULES where RULE_ID = :ruleId and PARTNER_ID =:partnerId");
		query.setString("ruleId", ruleId);
		query.setString("partnerId", partnerId);
		int delete = 0;
		 delete = query.executeUpdate();
		return delete;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RulesTable> findById(String ruleId, String partnerId) {
		Criteria criteria = getSession().createCriteria(RulesTable.class);
		criteria.add(Restrictions.eq("ruleId", ruleId));
		criteria.add(Restrictions.eq("partnerId", partnerId));
		return (List<RulesTable>) criteria.list();
	}

	@Override
	public void updateRules(RulesTable rule) {
		getSession().update(rule);

	}

	public void delete(long ruleId) {
		getSession().delete(ruleId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RulesTable> findByPartnerId(String partnerId) {
		Criteria criteria = getSession().createCriteria(RulesTable.class);
		criteria.add(Restrictions.eq("partnerId", partnerId));
		return (List<RulesTable>) criteria.list();

	}

	@Override
	public int deleteRuleByPartnerId(String partnerId) {
		Query query = getSession().createSQLQuery(
				"delete from RULES where PARTNER_ID = :partnerId");
		query.setString("partnerId", partnerId);
		query.executeUpdate();
		return 1;
	}

	@Override
	public boolean findRuleCountryCode(long cardNo, String countryCode,
			String identifierValue, String partnerId) {

		Criteria criteria = getSession().createCriteria(RulesTable.class);
		criteria.add(Restrictions.eq("cardNumber", cardNo));
		criteria.add(Restrictions.eq("countryCodes", countryCode));
		criteria.add(Restrictions.eq("identifierValues", identifierValue));
		criteria.add(Restrictions.eq("partnerId", partnerId));
		RulesTable rule = (RulesTable) criteria.uniqueResult();
		if (rule == null)
			return true;
		return false;
	}

	@Override
	public RulesTable findRuleByCardNo(long CardNo, String countryCode,
			String identifierId) {
		Criteria criteria = getSession().createCriteria(RulesTable.class);
		criteria.add(Restrictions.eq("cardNumber", CardNo));
		criteria.add(Restrictions.eq("countryCodes", countryCode));
		criteria.add(Restrictions.eq("identifierValues", identifierId));

		return (RulesTable) criteria.uniqueResult();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RulesTable> findByIdvalueIdentifier(String ruleId, String partnerId,
			String identifiervalue, String identifierType) {
		Criteria criteria = getSession().createCriteria(RulesTable.class);
		criteria.add(Restrictions.eq("ruleId", ruleId));
		criteria.add(Restrictions.eq("partnerId", partnerId));
		criteria.add(Restrictions.eq("identifierType", identifierType));
		criteria.add(Restrictions.eq("identifierValues", identifiervalue));

		return (List<RulesTable>) criteria.list();

	}

}
