package com.visa.dao;

import java.util.Date;
import java.util.List;

import com.visa.datamodel.NotificationTable;

public interface NotificationDao {

	void saveNotification(NotificationTable notification);

	List<NotificationTable> findByStartId(Date startFromId, String partnerId);

	NotificationTable findByNotifityId(String notifityId, String partnerId);

	List<NotificationTable> findByPartnerId(String partnerId);

}
