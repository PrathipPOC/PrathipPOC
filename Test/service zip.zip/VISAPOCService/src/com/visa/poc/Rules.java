package com.visa.poc;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Rules {
	
	private RuleRequest ruleRequest;
	private RuleUpdate ruleUpdate;
	private Rule rule;
	public RuleRequest getRuleRequest() {
		return ruleRequest;
	}
	public void setRuleRequest(RuleRequest ruleRequest) {
		this.ruleRequest = ruleRequest;
	}
	public RuleUpdate getRuleUpdate() {
		return ruleUpdate;
	}
	public void setRuleUpdate(RuleUpdate ruleUpdate) {
		this.ruleUpdate = ruleUpdate;
	}
	public Rule getRule() {
		return rule;
	}
	public void setRule(Rule rule) {
		this.rule = rule;
	}

	
}
