package com.visa.poc;

public enum IdentifierType {
	MCC,
	MID
}
