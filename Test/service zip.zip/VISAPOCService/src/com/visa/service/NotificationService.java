package com.visa.service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.visa.dao.NotificationDao;
import com.visa.dao.RulesDao;
import com.visa.datamodel.NotificationTable;
import com.visa.datamodel.RulesTable;
import com.visa.poc.Notification;
import com.visa.poc.OfferNotification;
import com.visa.poc.Response;

@RestController
@RequestMapping("/notification/{partnerId}")
// Notification Service create notification and get all notification methods.
public class NotificationService {
	final static Logger logger = Logger.getLogger(NotificationService.class);

	@Autowired
	NotificationDao dao;
	@Autowired
	RulesDao ruleDao;

	// create notification method
	@Async
	@RequestMapping(consumes = "application/JSON", method = RequestMethod.POST)
	public void create(@RequestBody long cardNumber, String countryCode,
			String identifierId, String transactionAmount) {

		// Check defined rules for given data.
		RulesTable rule = ruleDao.findRuleByCardNo(cardNumber, countryCode,
				identifierId);

		// Check if any rules available for given data
		if (rule != null && rule.getPaymentThreshold()<= Integer.parseInt(transactionAmount)) {

			Notification notification = new Notification();

			notification.setContent("Some Default Content");
			notification.setCountryCode(rule.getCountryCodes());
			notification.setLink("http://nowhere.com");
			notification.setNotificationId(UUID.randomUUID().toString());
			notification.setNotificationType("rule");
			notification.setTransactionAmount(transactionAmount);
			notification.setTransactionDateTime(new Date().toString());

			NotificationTable notifyObj = new NotificationTable();

			notifyObj.setNotificationId(notification.getNotificationId());
			notifyObj.setNotificationType(notification.getNotificationType());
			notifyObj.setContent(notification.getContent());
			notifyObj.setCountryCode(notification.getCountryCode());
			notifyObj.setLink(notification.getLink());
			notifyObj.setTransactionAmount(notification.getTransactionAmount());
			notifyObj.setTransactionDateTime(new Date());
			notifyObj.setPartnerId(rule.getPartnerId());
			// create offer notification call dao
			dao.saveNotification(notifyObj);
		}

	}

	// Get notification method
	@SuppressWarnings({ "rawtypes", "unused" })
	@RequestMapping(produces = "application/JSON", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity get(
			@PathVariable String partnerId,
			@RequestParam(value = "startFromId", required = false) String startFromId,
			@RequestParam(value = "notificationId", required = false) String notificationId) {
		logger.debug("Get notification for given PartnerId and notificationId: "
				+ partnerId + notificationId);
		logger.debug("startFromId: " + startFromId);

		OfferNotification offers = new OfferNotification();

		// Get notification for given partnerId and notificationId
		if (partnerId != null && notificationId != null && startFromId == null) {
			logger.debug("Get notification for given PartnerId and notificationId: "
					+ partnerId + notificationId);
			logger.debug("inside NofitifcationId block");
			// Check notification table for notifications available for given
			// partnerId and notificationId
			NotificationTable notification = dao.findByNotifityId(
					notificationId, partnerId);
			if(notification !=null){
			Notification notifyObj = new Notification();
			notifyObj.setContent(notification.getContent());
			notifyObj.setCountryCode(notification.getCountryCode());
			notifyObj.setLink(notification.getLink());
			notifyObj.setNotificationId(notification.getNotificationId());
			notifyObj.setNotificationType(notification.getNotificationType());
			notifyObj.setTransactionAmount(notification.getTransactionAmount());
			notifyObj.setTransactionDateTime(notification
					.getTransactionDateTime().toString());
			}
			// return notification details
			if(notification !=null){
			return new ResponseEntity<NotificationTable>(notification,
					HttpStatus.OK);
			}
			else{
				Response responseobj = new Response("Notification Not available for given notificationId",
						"404", "1", "http:");
				logger.error("No new notifications available for given partnerId: "+partnerId+" notificationId: "+notificationId);
				// Return http error message if partnerId not found
				return new ResponseEntity<Response>(responseobj, HttpStatus.NOT_FOUND);
			}

		}
		// Get notification for given partnerId and startfromId
		if (partnerId != null && startFromId != null && notificationId == null) {
			logger.debug("Get notification for given PartnerId and startFromId: "
					+ partnerId + startFromId);
			logger.debug("inside startId block");
			// Check notification table for notifications available for given
			// partnerId and startFromId
			NotificationTable notifyTime = dao.findByNotifityId(startFromId,
					partnerId);
			// check if notification available for given partnerId and
			// startfromId
			if (notifyTime != null) {

				Date timeStamp = notifyTime.getTransactionDateTime();
				// Get all notification available after given startfromId
				List<NotificationTable> notificationList = dao.findByStartId(
						timeStamp, partnerId);
				Notification[] notificationArr = new Notification[notificationList.size()];
				// check if notifications available after given startfromId
				if (!notificationList.isEmpty() && notificationList != null ) {
					int j = 0;					
					
					for (NotificationTable notification : notificationList) {
						Notification notifyObj = new Notification();
						notifyObj.setContent(notification.getContent());
						notifyObj.setCountryCode(notification.getCountryCode());
						notifyObj.setLink(notification.getLink());
						notifyObj.setNotificationId(notification
								.getNotificationId());
						notifyObj.setNotificationType(notification
								.getNotificationType());
						notifyObj.setTransactionAmount(notification
								.getTransactionAmount());
						notifyObj.setTransactionDateTime(notification
								.getTransactionDateTime().toString());
						notificationArr[j] = notifyObj;
						j++;
						
					}
										
				}
				if(!notificationList.isEmpty() && notificationArr != null){
					offers.setNotifications(notificationArr);
					// return all notification created after given startfromId
					return new ResponseEntity<OfferNotification>(offers,
							HttpStatus.OK);
					}
					else{
						Response responseobj = new Response("No new notifications available",
								"404", "1", "http:");
						logger.error("No new notifications available for given partnerId: "+partnerId+" startFromId: "+startFromId);
						// Return http error message if partnerId not found
						return new ResponseEntity<Response>(responseobj, HttpStatus.NOT_FOUND);
					}
			}
		}
		// Get all notifications for given partnerId
		if (partnerId != null && startFromId == null && notificationId == null) {
			logger.debug("Get notification for given PartnerId: " + partnerId);
			logger.debug("inside partnerId block");
			// Get notifications available for given partnerId
			List<NotificationTable> notificationList = dao
					.findByPartnerId(partnerId);
			// check notification available for given partnerId
			if (notificationList != null && !notificationList.isEmpty()) {
				System.out.println("inside notification list");
				int i = notificationList.size();

				int j = 0;
				Notification[] notificationArr = new Notification[i];

				for (NotificationTable notification : notificationList) {
					Notification notify = new Notification();

					notify.setContent(notification.getContent());
					notify.setCountryCode(notification.getCountryCode());
					notify.setLink(notification.getLink());
					notify.setNotificationId(notification.getNotificationId());
					notify.setNotificationType(notification
							.getNotificationType());
					notify.setTransactionAmount(notification
							.getTransactionAmount());
					notify.setTransactionDateTime(notification
							.getTransactionDateTime().toString());
					notificationArr[j] = notify;
					j++;
				}
				if(notificationArr != null){
					System.out.println("*****inside Notification Array return");
				offers.setNotifications(notificationArr);
				// Return all notification for given partnerId
				return new ResponseEntity<OfferNotification>(offers,
						HttpStatus.OK);
				}
				else{
					Response responseobj = new Response("PartnerId not found",
							"404", "1", "http:");
					logger.error("PartnerId not found");
					// Return http error message if partnerId not found
					return new ResponseEntity<Response>(responseobj, HttpStatus.NOT_FOUND);
				}

			}
		}

		Response responseobj = new Response("Invalid URL/partnerId/notificationId", "500",
				"1", "http:");
		logger.error("PartnerId not available");
		// Return http response for all failure cases
		return new ResponseEntity<Response>(responseobj,
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

}