package com.visa.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.visa.dao.RulesDao;
import com.visa.datamodel.RulesTable;
import com.visa.poc.IdentifierType;
import com.visa.poc.Response;
import com.visa.poc.Rule;
//import com.visa.poc.Rules;
import com.visa.poc.Rules;

@RestController
@RequestMapping("/rules/{partnerId}")
public class RulesService {

	@Autowired
	private RulesDao dao;
	
	@Autowired
	private Environment envar;
	
	RulesTable ruleTabObj = new RulesTable();

	final static Logger logger = Logger.getLogger(RulesService.class);

	// Create Rule method
	@RequestMapping(consumes = "application/JSON", produces = "application/JSON", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<Response> post(
			@PathVariable String partnerId, @RequestBody Rules ruleRequest) {
		logger.debug("Create rule for PartnerId: " + partnerId);

		int save = 0;
		String ruleId = UUID.randomUUID().toString();
		// check ruleRequet, partnerId not null
		if (ruleRequest != null
				&& partnerId != null && ruleRequest.getRuleRequest().getCardNumber().length() >= Integer.parseInt(envar.getProperty("cardnumber.length"))
				) {
			for (int i = 0; i < ruleRequest.getRuleRequest().getCountryCodes().length; i++) {

				long cardNo = Long.parseLong(ruleRequest.getRuleRequest()
						.getCardNumber());
				String countryCode = ruleRequest.getRuleRequest()
						.getCountryCodes()[i];
				String identifierValue = ruleRequest.getRuleRequest()
						.getIdentifierValues();

				ruleTabObj.setCardNumber(cardNo);
				ruleTabObj.setCountryCodes(countryCode);
				ruleTabObj.setIdentifierType(ruleRequest.getRuleRequest()
						.getIdentifierType().toString());
				ruleTabObj.setIdentifierValues(identifierValue);
				ruleTabObj.setPartnerId(partnerId);
				ruleTabObj.setPaymentThreshold(Double.parseDouble(ruleRequest
						.getRuleRequest().getPaymentThreshold()));
				ruleTabObj.setRuleId(ruleId);

				logger.debug("Before Calling rule DAO");
				// check if already a rule exist for given ruleRquest
				if (dao.findRuleCountryCode(cardNo, countryCode,
						identifierValue, partnerId) == true) {
					// create rule calling dao to save rules
					save = dao.saveRules(ruleTabObj);
				}

				logger.debug("After Calling rule DAO");

			}
			// set response message for rule request
			if (save == 1) {

				Response status = new Response("Rule created", "200", "0",
						"success:");
				// Return success response if rule created
				return new ResponseEntity<Response>(status, HttpStatus.OK);
			}
			else{
				Response responseobj = new Response("Rule Already Exist", "500", "1",
						"http:");
				logger.error("Rule Already Exist");
				// Return error message with http response
				return new ResponseEntity<Response>(responseobj,
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
		}
		Response responseobj = new Response("Invalid Card Number", "500", "1",
				"http:");
		logger.error("Invalid card number");
		// Return error message with http response
		return new ResponseEntity<Response>(responseobj,
				HttpStatus.INTERNAL_SERVER_ERROR);
		

	}

	// Get available rules method
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(produces = "application/JSON", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity get(@PathVariable String partnerId,
			@RequestParam(value = "ruleId", required=false) String ruleId) {
		logger.debug("Get rules for given partnerId: " + partnerId);
		Rules ruleObj = new Rules();

		Rule rulById = new Rule();
		// Check rules for given partnerId and ruleId
		if (partnerId != null) {
			if (ruleId != null && ruleId.length() > 16) {
				logger.debug("Get rule for given partnerId: " + partnerId
						+ "ruleId: " + ruleId);
				int i = 0;
				// Get rule for given ruleId and partnerId calling dao method
				List<RulesTable> ruleTabList = dao.findById(ruleId, partnerId);
				String[] countryCode = new String[ruleTabList.size()];
				// check if rule is available for given partnerId and ruleId
				if (ruleTabList.size() > 0) {
					logger.debug("Rule available for given partnerId: "
							+ partnerId + "ruleId: " + ruleId);
					for (RulesTable ruleById : ruleTabList) {

						if (i == 0) {

							rulById.setCardNumber("" + ruleById.getCardNumber());
							String identifierType = ruleById
									.getIdentifierType();
							// check identifiertype for rule fetch by id
							if (identifierType.equals("MCC"))
								rulById.setIdentifierType(IdentifierType.MCC);
							if (identifierType.equals("MID"))
								rulById.setIdentifierType(IdentifierType.MID);
							rulById.setIdentifierValues(ruleById
									.getIdentifierValues());
							rulById.setPaymentThreshold(""
									+ ruleById.getPaymentThreshold());
							rulById.setRuleId(ruleById.getRuleId());
							countryCode[i] = ruleById.getCountryCodes();
						} else {
							logger.debug("else country"
									+ ruleById.getCountryCodes());
							countryCode[i] = ruleById.getCountryCodes();
						}
						i++;

					}
					rulById.setCountryCodes(countryCode);
					ruleObj.setRule(rulById);
					// Return rule details along with http success message
					return new ResponseEntity<Rules>(ruleObj, HttpStatus.OK);
				}

			}
		} else {

			Response responseobj = new Response("Invalid PartnerId/RuleID",
					"500", "1", "http:");
			logger.error("Invalid RuleID:");
			// Return http failure message
			return new ResponseEntity<Response>(responseobj,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		// Check rules created for partnerId
		if (ruleId == null && partnerId != null) {
			// get rules created for partnerId
			List<RulesTable> ruleTabList = dao.findByPartnerId(partnerId);
			ArrayList<Rules> ruleArray = new ArrayList<Rules>();
			String rulId = null;
			for (RulesTable ruleTabRecord : ruleTabList) {
				String rul = ruleTabRecord.getRuleId();
				if (!rul.equals(rulId)) {
					List<RulesTable> ruleListById = dao
							.findById(rul, partnerId);
					if (ruleListById.size() > 0) {
						int i = 0;
						ArrayList<String> country = new ArrayList<String>();
						Rule rulesRow = new Rule();
						Rules rulObj = new Rules();
						for (RulesTable ruleById : ruleListById) {
							if (i == 0) {
								rulesRow.setCardNumber(""
										+ ruleById.getCardNumber());
								String identifierType = ruleById
										.getIdentifierType();
								if (identifierType.equals("MCC"))
									rulesRow.setIdentifierType(IdentifierType.MCC);
								if (identifierType.equals("MID"))
									rulesRow.setIdentifierType(IdentifierType.MID);
								rulesRow.setIdentifierValues(ruleById
										.getIdentifierValues());
								rulesRow.setPaymentThreshold(""
										+ ruleById.getPaymentThreshold());
								rulesRow.setRuleId(ruleById.getRuleId());
								country.add(ruleById.getCountryCodes());

							} else {
								country.add(ruleById.getCountryCodes());
							}

							i++;
						}
						String[] countryCode = country
								.toArray(new String[country.size()]);
						rulesRow.setCountryCodes(countryCode);
						rulObj.setRule(rulesRow);
						ruleArray.add(rulObj);
					}
					rulId = ruleTabRecord.getRuleId();
				}
			}
			if (ruleTabList.size() == 0) {

				Response responseobj = new Response("Invalid PartnerId", "500",
						"1", "http:");
				// Return http error resposne if not rules available
				return new ResponseEntity<Response>(responseobj,
						HttpStatus.INTERNAL_SERVER_ERROR);
			} else {
				// Return all rules fetched from table and http success message
				return new ResponseEntity(ruleArray, HttpStatus.OK);
			}
		}

		Response responseobj = new Response("Invalid PartnerId/RuleId", "500",
				"1", "http:");
		logger.error("Invalid RuleID");
		// Return http error resposne if not rules available for any of the
		// conditions
		return new ResponseEntity<Response>(responseobj,
				HttpStatus.INTERNAL_SERVER_ERROR);

	}

	// Put method to update existing rules
	@SuppressWarnings("rawtypes")
	@RequestMapping(consumes = "application/JSON", produces = "application/JSON", method = RequestMethod.PUT)
	public @ResponseBody ResponseEntity put(@PathVariable String partnerId,
			@RequestParam(value="ruleId", required=false) String ruleId, @RequestBody Rules ruleUpdate) {
		// Get rule by ruleId and partnerId to update
		if (partnerId != null && ruleId != null) {
			logger.debug("fetch rule for given partnerId: " + partnerId
					+ " and ruleId: " + ruleId);
			String identifierType = ruleUpdate.getRuleUpdate()
					.getIdentifierType().toString();
			String identifiervalue = ruleUpdate.getRuleUpdate()
					.getIdentifierValues();
			// find rule for given partnerId and ruleId
			List<RulesTable> ruleList = dao.findByIdvalueIdentifier(ruleId,partnerId,
					identifiervalue, identifierType);
			if (ruleList.size() > 0) {
				for (RulesTable rulTabObj : ruleList) {

					rulTabObj.setPaymentThreshold(Double.parseDouble(ruleUpdate
							.getRuleUpdate().getPaymentThreshold()));
					// update rule for the given partnerId and ruleId
					dao.updateRules(rulTabObj);
					logger.debug("Updated rule for given partnerId: "
							+ partnerId + " and ruleId: " + ruleId);
				}
				Response responseobj = new Response("Rule Updated", "200", "1",
						"http:");
				// Return success message for rule updated
				return new ResponseEntity<Response>(responseobj, HttpStatus.OK);
			} else {
				Response responseobj = new Response("Rule Not found", "404",
						"1", "http:");
				// Return http error message if rule not found
				return new ResponseEntity<Response>(responseobj,
						HttpStatus.NOT_FOUND);

			}
		}
		
			Response responseobj = new Response("Invalid RuleID", "400", "1",
					"http:");
			// Return http error message if rule not found
			logger.error("Invalid RuleID");

			return new ResponseEntity<Response>(responseobj, HttpStatus.BAD_REQUEST);
		
	}

	// Delete method to delete existing rules
	@RequestMapping(produces = "application/JSON", method = RequestMethod.DELETE)
	public @ResponseBody ResponseEntity<Response> delete(
			@PathVariable String partnerId,
			@RequestParam(value = "ruleId", required = false) String ruleId) {
		// Check rules for given partnerId and ruleId
		if (partnerId != null && ruleId != null ) {
			logger.debug("Delete rule by given partnerId: " + partnerId
					+ " and ruleId: " + ruleId);
			List<RulesTable> ruleTabList = dao.findById(ruleId, partnerId);
			if(!ruleTabList.isEmpty() && ruleTabList != null){
			int delete = dao.deleteRulesById(ruleId, partnerId);
			Response status = new Response(
					"Rule Related to PartnerId and RuleId deleted", "200", "0",
					"success:");
				// Return success message if rule is deleted
				return new ResponseEntity<Response>(status, HttpStatus.OK);
		}
		}
		// Check rules for given partnerId
		if (partnerId != null && ruleId == null) {
			logger.debug("Delete rule by given partnerId: " + partnerId);
			List<RulesTable> ruleTabList = dao.findByPartnerId(partnerId);
			if(!ruleTabList.isEmpty() && ruleTabList != null){
			int delete = dao.deleteRuleByPartnerId(partnerId);
			if (delete == 1) {
				Response status = new Response(
						"All Rules Related to PartnerId deleted", "200", "0",
						"success:");
				// Return success message if all rules is deleted for given
				// partnerId
				return new ResponseEntity<Response>(status, HttpStatus.OK);
			}
			}
		}

		Response responseobj = new Response("RuleId/PartnerId not found",
				"404", "1", "http:");
		logger.error("RuleId and PartnerId not available");
		// Return http error message if rule not found
		return new ResponseEntity<Response>(responseobj, HttpStatus.NOT_FOUND);

	}

}
