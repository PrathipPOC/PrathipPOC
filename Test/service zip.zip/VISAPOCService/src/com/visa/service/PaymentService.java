package com.visa.service;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.visa.dao.RulesDao;
import com.visa.poc.AuthenticationResponse;
import com.visa.poc.AuthorisationDetails;
import com.visa.poc.Payment;
import com.visa.poc.Response;
import com.visa.poc.ReturnAndResponseDetails;

@RestController
@EnableAsync
@Configuration
@PropertySource(value = { "classpath:application.properties" })
@RequestMapping("/payments")
public class PaymentService {
	final static Logger logger = Logger.getLogger(PaymentService.class);

	@Autowired
	NotificationService notificationService;

	@Autowired
	private org.springframework.core.env.Environment environment;
	
	@Autowired
	private Environment envar;
	
	@Autowired
	RulesDao ruleDao;

	// Payment authorization method
	@SuppressWarnings("rawtypes")
	@RequestMapping(consumes = "application/JSON", produces = "application/JSON", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity authorisation(
			@RequestBody Payment payment) throws Exception {
		Payment status = new Payment();
		// check cardno used for payment is valid or invalid
		if (payment.getAuthenticationRequest().getConsumerCardDetails()
				.getCardNumber().length() >= Integer.parseInt(envar.getProperty("cardnumber.length"))) {
			// set authorization response message
			AuthenticationResponse authResponse = new AuthenticationResponse();

			authResponse.setRequestID("JDXGG86P5LZ28TM3BBVSVC1");
			authResponse.setRequestType("Authorisation");
			authResponse.setVmeMerchantID("123abc7juGH23def7890");
			authResponse.setLink("http://nowhere.com");
			ReturnAndResponseDetails returnobj = new ReturnAndResponseDetails();

			returnobj.setAuthorisationRequestStatus("Authorised");
			returnobj.setReturnReasonCode("00");
			returnobj.setPspReturnReasonDescription("Authorised");
			returnobj
					.setPspPassThroughData("PSP Ident:123456, TrickyTrainers, PSP\r\nreq:234567");
			returnobj.setPspStartTime("2012-05-14T16:09:03.742507Z");
			returnobj.setPspEndTime("2012-05-14T16:15:03.74200Z");
			returnobj.setNativeCSCResponseCode("Y");
			returnobj.setNativeAVSResponseCode("M");
			authResponse.setReturnAndResponseDetails(returnobj);

			AuthorisationDetails detailsobj = new AuthorisationDetails();

			detailsobj.setAcquirerBankIDCode("987654321");
			detailsobj.setAcquirerMerchantId("444");
			detailsobj.setAuthorisationCode("123456");
			detailsobj.setAuthorisationTimestamp(new Date().toString());
			authResponse.setAuthorisationDetails(detailsobj);

			status.setAuthenticationResponse(authResponse);

			long cardNumber = Long.parseLong(payment.getAuthenticationRequest()
					.getConsumerCardDetails().getCardNumber());
			String countryCode = payment.getAuthenticationRequest()
					.getpSPMerchantID().getCountryCode();
			String identifierId = payment.getAuthenticationRequest()
					.getpSPMerchantID().getId();
			String transactionAmount = payment.getAuthenticationRequest()
					.getTotalAuthorisationAmount();
			// Asyn call for notification create method
			logger.debug("Before calling notification create for cardno: "
					+ cardNumber);
			notificationService.create(cardNumber, countryCode, identifierId,
					transactionAmount);
			logger.debug("After calling notification create for cardno: "
					+ cardNumber);
			// Return success response for all payment
			return new ResponseEntity<Payment>(status, HttpStatus.OK);
		}
		else{
			return new ResponseEntity<Payment>(status, HttpStatus.OK);
		}
		

	}

}
