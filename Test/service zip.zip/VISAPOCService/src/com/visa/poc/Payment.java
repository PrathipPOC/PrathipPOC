package com.visa.poc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class Payment {

	private AuthenticationRequest authenticationRequest;
	private AuthenticationResponse authenticationResponse;
	
	public AuthenticationRequest getAuthenticationRequest() {
		return authenticationRequest;
	}
	public void setAuthenticationRequest(AuthenticationRequest authenticationRequest) {
		this.authenticationRequest = authenticationRequest;
	}
	public AuthenticationResponse getAuthenticationResponse() {
		return authenticationResponse;
	}
	public void setAuthenticationResponse(
			AuthenticationResponse authenticationResponse) {
		this.authenticationResponse = authenticationResponse;
	}
	
}
