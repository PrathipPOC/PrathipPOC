package com.visa.poc;

public class AuthenticationRequest {

	private String requestID;
	private String requestType;
	private String vmeMerchantID;
	private String sessionID;
	private String shopperIPAddress;
	private String merchantPassThroughData;
	private String orderNumber;
	private String orderDate;
	private String invoiceNumber;
	private String invoiceDate;
	private String orderCurrency;
	private String totalAuthorisationAmount;
	private MerchantItemDetails[] merchantItemDetails;
	private ConsumerCardDetails consumerCardDetails;
	private ConsumerCardVerificationDetails consumerCardVerificationDetails;
	private ConsumerBillingDetails consumerBillingDetails;
	private MerchantShippingDetails merchantShippingDetails;
	private ThreeDSecure threeDSecure;
	private VmeTransactionIdentifier vmeTransactionIdentifier;
	private PSPMerchantID pSPMerchantID;
	
	public String getRequestID() {
		return requestID;
	}
	public PSPMerchantID getpSPMerchantID() {
		return pSPMerchantID;
	}
	public void setpSPMerchantID(PSPMerchantID pSPMerchantID) {
		this.pSPMerchantID = pSPMerchantID;
	}
	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getVmeMerchantID() {
		return vmeMerchantID;
	}
	public void setVmeMerchantID(String vmeMerchantID) {
		this.vmeMerchantID = vmeMerchantID;
	}
	
	public String getSessionID() {
		return sessionID;
	}
	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}
	public String getShopperIPAddress() {
		return shopperIPAddress;
	}
	public void setShopperIPAddress(String shopperIPAddress) {
		this.shopperIPAddress = shopperIPAddress;
	}
	public String getMerchantPassThroughData() {
		return merchantPassThroughData;
	}
	public void setMerchantPassThroughData(String merchantPassThroughData) {
		this.merchantPassThroughData = merchantPassThroughData;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getInvoiceDate() {
		return invoiceDate;
	}
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	public String getOrderCurrency() {
		return orderCurrency;
	}
	public void setOrderCurrency(String orderCurrency) {
		this.orderCurrency = orderCurrency;
	}
	public String getTotalAuthorisationAmount() {
		return totalAuthorisationAmount;
	}
	public void setTotalAuthorisationAmount(String totalAuthorisationAmount) {
		this.totalAuthorisationAmount = totalAuthorisationAmount;
	}
	public MerchantItemDetails[] getMerchantItemDetails() {
		return merchantItemDetails;
	}
	public void setMerchantItemDetails(MerchantItemDetails[] merchantItemDetails) {
		this.merchantItemDetails = merchantItemDetails;
	}
	public ConsumerCardDetails getConsumerCardDetails() {
		return consumerCardDetails;
	}
	public void setConsumerCardDetails(ConsumerCardDetails consumerCardDetails) {
		this.consumerCardDetails = consumerCardDetails;
	}
	public ConsumerCardVerificationDetails getConsumerCardVerificationDetails() {
		return consumerCardVerificationDetails;
	}
	public void setConsumerCardVerificationDetails(
			ConsumerCardVerificationDetails consumerCardVerificationDetails) {
		this.consumerCardVerificationDetails = consumerCardVerificationDetails;
	}
	public ConsumerBillingDetails getConsumerBillingDetails() {
		return consumerBillingDetails;
	}
	public void setConsumerBillingDetails(
			ConsumerBillingDetails consumerBillingDetails) {
		this.consumerBillingDetails = consumerBillingDetails;
	}
	public MerchantShippingDetails getMerchantShippingDetails() {
		return merchantShippingDetails;
	}
	public void setMerchantShippingDetails(
			MerchantShippingDetails merchantShippingDetails) {
		this.merchantShippingDetails = merchantShippingDetails;
	}
	public ThreeDSecure getThreeDSecure() {
		return threeDSecure;
	}
	public void setThreeDSecure(ThreeDSecure threeDSecure) {
		this.threeDSecure = threeDSecure;
	}
	public VmeTransactionIdentifier getVmeTransactionIdentifier() {
		return vmeTransactionIdentifier;
	}
	public void setVmeTransactionIdentifier(
			VmeTransactionIdentifier vmeTransactionIdentifier) {
		this.vmeTransactionIdentifier = vmeTransactionIdentifier;
	}
	
}
